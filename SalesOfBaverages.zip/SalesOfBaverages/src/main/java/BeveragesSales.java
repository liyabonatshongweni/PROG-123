/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public abstract class BeveragesSales {
    private String BeverageType;
    private String City;
    private int totalSales;
    
    //Constructor
    public Beverage(String BeverageType, String city, int totalSales){
        this.BeverageType = BeverageType;
        this.store = store;
        this.totalSales = totalSales;
    }
    //get beverageType
    public String getBeverageType(){
        return BeverageType;
    }
    //get city names
    public String getCity(){
        return city;
    }
    //get total sales
    public int getTotalSales(){
        return totalSales;
    }
}
