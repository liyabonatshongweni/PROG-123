/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.salesofbaverages;

/**
 *
 * @author Student
 */
public class SalesOfBaverages {

    public static void main(String[] args) {
        
        //Single dimentional array for Cities
        String[] cities = {"Cape Town", "Port Elizabeth", "Ptretoria"};
        //Two dimentional array for console sales 
        int[][] sales = {{500, 300, 125},//Cape Town
        {450, 250, 100},//Port Elizabet
            {480, 175, 120},//Pretoria
            
            
        };
        
        String[] consoles = {"Coffe", "Tea","Boba Tea"};
        System.out.println("Sales of Baverages");
        System.out.println("----");
        System.out.println("beverage[0],beverage[1], beverage[2]");
        
         //Display sales table 
        for(int i = 0;i< cities,length;i++){
        System.out.printf("%-15s",cities[0]);
    }
        
        System.out.println();
        System.out.println("Hut Beverages report");
        System.out.println("------");
        
           int highestSales = 0;
        String highestCity =" ",
                
                //Calculating totals
                for (int i=0;i< cities.length;i++){
                    int total=0;
                    {
                    total +=sales[i][0];
                    
                }
                    System.out.println(cities[i]+"="+total);
                    if(total>highestSales){
                        highestSales = total;
                        highestCity = cities[i];
                    }
                }
        
        System.out.println();
        System.out.println("CITY WITH THE MOST SALES:" + highestCity);
        
    }
}
